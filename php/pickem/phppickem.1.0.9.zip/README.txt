PHP Pick 'Em

*SEE docs/Readme.doc

Please read license.txt for usage terms.

Contents:
1. Minimum Requirements
2. Installation Instructions
3. Logging In
4. Troubleshooting

1. Minimum Requirements
PHP version 4.3 or greater
MySql version 4.0 or greater

2. Installation Instructions

2.1. Extract files
2.2. Create a MySQL database on your web server, as well as a MySQL user who has all privileges for accessing and modifying it.
2.3. Edit /includes/config.php and update database connection variables accordingly
2.4. Upload files to your web server
2.5. Run installer script at http://www.your-domain.com/phppickem/install.  The installer will assist you with the rest.

3. Logging In

3.1 Log in for the first time with admin / admin123.  You may change your password once you are logged in.

4. Troubleshooting
For help, please visit: http://www.phppickem.com/
